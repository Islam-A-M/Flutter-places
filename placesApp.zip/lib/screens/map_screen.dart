import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import '../models/place.dart';

class MapScreen extends StatefulWidget {
  final PlaceLocation initialLocation;
  final bool isSelecting;
/*     Future<void> _getCurrentUserLocation() async {
    final locData = await Location().getLocation();
initialLocation=PlaceLocation(latitude: locData.latitude, longitude: locData.longitude);
  } */
  MapScreen(
      {this.initialLocation =
          const PlaceLocation(latitude: 30.003931, longitude: 31.171827),
      this.isSelecting = false});

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  LatLng _pickedLocation;
  void _selectLocation(LatLng postion) {
    setState(() {
      _pickedLocation = postion;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Map'),
        actions: [
          if (widget.isSelecting)
            IconButton(
              icon: Icon(Icons.check),
              onPressed: _pickedLocation == null
                  ? null
                  : () {
                      Navigator.of(context).pop(_pickedLocation);
                    },
            )
        ],
      ),
      body: GoogleMap(
          initialCameraPosition: CameraPosition(
              zoom: 16,
              target: LatLng(
                widget.initialLocation.latitude,
                widget.initialLocation.longitude,
              )),
          onTap: widget.isSelecting ? _selectLocation : null,
          markers: (_pickedLocation == null && widget.isSelecting)
              ? null
              : {
                  Marker(
                    markerId: MarkerId('m1'),
                    position: _pickedLocation ??
                        LatLng(widget.initialLocation.latitude,
                            widget.initialLocation.longitude),
                  ),
                }),
    );
  }
}
